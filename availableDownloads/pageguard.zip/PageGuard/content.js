// content.js

(function() {
  'use strict';

  const HOSTNAME = location.hostname;
  const STORAGE_KEY = "lockedSites";
  let storedHash = null;

  async function sha256(str) {
    const buf = new TextEncoder().encode(str);
    const hashBuffer = await crypto.subtle.digest('SHA-256', buf);
    return Array.from(new Uint8Array(hashBuffer))
      .map(b => b.toString(16).padStart(2, '0'))
      .join('');
  }

  function checkLock() {
    chrome.storage.local.get({ [STORAGE_KEY]: {} }, async (data) => {
      const locked = data[STORAGE_KEY] || {};
      for (const key in locked) {
        if (HOSTNAME.includes(key) || location.href.includes(key)) {
          storedHash = locked[key];
          if (!sessionStorage.getItem("unlocked:" + HOSTNAME)) {
            createLockScreen();
          }
          return;
        }
      }
    });
  }

  function createLockScreen() {
    if (document.getElementById('lock-overlay')) return;

    const overlay = document.createElement('div');
    overlay.id = 'lock-overlay';
    overlay.style.cssText = `
      position:fixed;inset:0;background:#0a0a0a;z-index:2147483647;
      display:flex;align-items:center;justify-content:center;
      font-family:system-ui,sans-serif;color:#e5e5e5;
    `;

    overlay.innerHTML = `
      <div style="background:#111;padding:48px 40px;border-radius:16px;width:380px;max-width:92%;
                  text-align:center;border:1px solid #222;box-shadow:0 20px 60px rgba(0,0,0,0.5);position:relative;">
        <h2 style="margin:0 0 24px;font-size:26px;font-weight:600;color:#fff;">Erişim Kısıtlı</h2>
        <p style="margin:0 0 32px;color:#888;font-size:15px;">Şifreyi girin veya geçici bakın</p>

        <input type="password" id="lock-pass" autocomplete="off"
          style="width:100%;padding:14px 16px;font-size:16px;background:#1a1a1a;border:1px solid #333;
                 border-radius:10px;color:#fff;margin-bottom:20px;outline:none;transition:border-color .2s;"
          placeholder="Şifre">

        <button id="unlock-btn" style="width:100%;padding:14px;font-size:16px;font-weight:500;
               background:#ffffff;color:#000;border:none;border-radius:10px;cursor:pointer;margin-bottom:12px;">
          Kilidi Aç
        </button>

        <button id="temp-btn" style="width:100%;padding:12px;font-size:15px;background:#1f1f1f;color:#fff;
               border:none;border-radius:10px;cursor:pointer;">
          30 Saniye Geçici Bak
        </button>

        <p id="lock-error" style="color:#ff4d4d;margin-top:20px;font-size:14px;min-height:20px;"></p>

        <!-- Kalan süre sayacı -->
        <div id="timer" style="position:absolute;bottom:16px;right:20px;background:rgba(0,0,0,0.7);
             padding:6px 12px;border-radius:8px;font-size:13px;color:#ccc;display:none;">
          Kalan: <span id="seconds">30</span> sn
        </div>
      </div>
    `;

    document.documentElement.appendChild(overlay);

    const input = document.getElementById('lock-pass');
    const error = document.getElementById('lock-error');
    const unlockBtn = document.getElementById('unlock-btn');
    const tempBtn = document.getElementById('temp-btn');
    const timerEl = document.getElementById('timer');
    const secondsEl = document.getElementById('seconds');

    input.focus();

    unlockBtn.addEventListener('click', async () => {
      const val = input.value;
      if (!val) return error.textContent = "Şifre girin";
      const inputHash = await sha256(val);
      if (inputHash === storedHash) {
        sessionStorage.setItem("unlocked:" + HOSTNAME, "1");
        overlay.remove();
      } else {
        error.textContent = "Yanlış şifre";
        input.value = '';
        input.focus();
      }
    });

tempBtn.addEventListener('click', () => {
  sessionStorage.setItem("unlocked:" + HOSTNAME, "1");
  overlay.remove();

  // Sayaçı doğrudan body'ye ekle (kalıcı olsun)
  const timerDiv = document.createElement('div');
  timerDiv.id = 'global-timer';
  timerDiv.style.cssText = `
    position: fixed; bottom: 20px; right: 20px;
    background: rgba(0,0,0,0.8); color: #ccc;
    padding: 8px 16px; border-radius: 8px;
    font-size: 14px; z-index: 2147483646;
  `;
  timerDiv.innerHTML = 'Kalan: <span id="seconds">30</span> sn';
  document.body.appendChild(timerDiv);

  let timeLeft = 30;
  const secondsEl = document.getElementById('seconds');

  const countdown = setInterval(() => {
    timeLeft--;
    secondsEl.textContent = timeLeft;
    if (timeLeft <= 0) {
      clearInterval(countdown);
      timerDiv.remove();
      sessionStorage.removeItem("unlocked:" + HOSTNAME);
      location.reload();
    }
  }, 1000);

  // Butonu devre dışı bırak
  tempBtn.disabled = true;
  tempBtn.textContent = "30sn Bekle";
  tempBtn.style.opacity = '0.5';
});

    input.addEventListener('input', () => error.textContent = '');
  }

  function protect() {
    if (storedHash && !sessionStorage.getItem("unlocked:" + HOSTNAME)) {
      if (!document.getElementById('lock-overlay')) createLockScreen();
    }
  }

  const observer = new MutationObserver(protect);
  observer.observe(document.documentElement, { childList: true, subtree: true });

  setInterval(protect, 400);

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', checkLock);
  } else {
    checkLock();
  }

  const originalRemove = Element.prototype.remove;
  Element.prototype.remove = function() {
    if (this.id === 'lock-overlay') {
      observer.disconnect();
    }
    originalRemove.apply(this, arguments);
  };
})();