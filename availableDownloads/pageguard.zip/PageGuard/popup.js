document.addEventListener('DOMContentLoaded', () => {
  const siteInput = document.getElementById('site');
  const passInput = document.getElementById('password');
  const lockBtn = document.getElementById('lock');
  const currentBtn = document.getElementById('current');
  const statusEl = document.getElementById('status');
  const fullList = document.getElementById('fullList');

  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    if (tabs[0]?.url) {
      try {
        const url = new URL(tabs[0].url);
        siteInput.placeholder = url.hostname;
      } catch {}
    }
  });

  function showStatus(text, error = false) {
    statusEl.textContent = text;
    statusEl.className = error ? 'error' : 'success';
    setTimeout(() => statusEl.textContent = '', 3000);
  }

  async function sha256(str) {
    const buf = new TextEncoder().encode(str);
    const hash = await crypto.subtle.digest('SHA-256', buf);
    return Array.from(new Uint8Array(hash)).map(b => b.toString(16).padStart(2, '0')).join('');
  }

  function loadSites() {
    chrome.storage.local.get({ lockedSites: {} }, (data) => {
      const sites = Object.keys(data.lockedSites || {});
      fullList.innerHTML = '';

      if (sites.length === 0) {
        fullList.innerHTML = '<div style="text-align:center; color:var(--text-secondary); padding:30px;">Henüz kilitli site yok</div>';
        return;
      }

      sites.forEach(site => {
        const item = document.createElement('div');
        item.className = 'site-item';
        item.innerHTML = `<span>${site}</span><button class="delete-btn" data-site="${site}">Sil</button>`;
        fullList.appendChild(item);
      });

      document.querySelectorAll('.delete-btn').forEach(btn => {
        btn.addEventListener('click', async () => {
          const site = btn.dataset.site;
          const pass = prompt(`"${site}" kilidini kaldırmak için şifreyi girin:`);
          if (!pass) return;

          const inputHash = await sha256(pass);
          chrome.storage.local.get({ lockedSites: {} }, (data) => {
            const locked = data.lockedSites || {};
            if (locked[site] === inputHash) {
              delete locked[site];
              chrome.storage.local.set({ lockedSites: locked }, () => {
                showStatus(`Kilidi kaldırıldı: ${site}`);
                loadSites();
              });
            } else {
              showStatus('Yanlış şifre!', true);
            }
          });
        });
      });
    });
  }

  function showPage(pageId) {
    document.querySelectorAll('.page').forEach(p => p.classList.remove('active'));
    document.getElementById(pageId).classList.add('active');
  }

  document.getElementById('show-locked').addEventListener('click', () => {
    showPage('locked-page');
    loadSites();
  });

  document.getElementById('back').addEventListener('click', () => {
    showPage('main-page');
  });

  lockBtn.addEventListener('click', async () => {
    const site = siteInput.value.trim().toLowerCase();
    const pass = passInput.value;

    if (!site || !pass) {
      showStatus('Site ve şifre gerekli!', true);
      return;
    }

    const hash = await sha256(pass);

    chrome.storage.local.get({ lockedSites: {} }, (data) => {
      const locked = data.lockedSites || {};
      if (locked[site]) {
        showStatus('Bu site zaten kilitli!', true);
        return;
      }
      locked[site] = hash;
      chrome.storage.local.set({ lockedSites: locked }, () => {
        showStatus(`Kilitlendi: ${site}`);
        siteInput.value = '';
        passInput.value = '';
      });
    });
  });

  currentBtn.addEventListener('click', () => {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      if (tabs[0]?.url) {
        try {
          const url = new URL(tabs[0].url);
          siteInput.value = url.hostname;
          showStatus(`Mevcut site: ${url.hostname}`);
        } catch {
          showStatus('Sekme okunamadı', true);
        }
      }
    });
  });
});