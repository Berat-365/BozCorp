document.addEventListener("DOMContentLoaded", async () => {
  const bulkBtn = document.getElementById("bulkSave");
  const formatSelect = document.getElementById("format");
  const jpgInput = document.getElementById("jpgQuality");
  const savePathInput = document.getElementById("savePath");
  const historyBtn = document.getElementById("showHistory");
  const clearHistoryBtn = document.getElementById("clearHistory");
  const historyContainer = document.getElementById("historyContainer");
  const statsElem = document.getElementById("stats");

  // Storage'dan yükle
  chrome.storage.sync.get(["defaultFormat","jpgQuality","savePath"], data=>{
    if(data.defaultFormat) formatSelect.value = data.defaultFormat;
    if(data.jpgQuality) jpgInput.value = data.jpgQuality;
    if(data.savePath) savePathInput.value = data.savePath;
  });

  // Ayar değişiklikleri kaydet
  formatSelect.addEventListener("change",()=> {
    chrome.storage.sync.set({defaultFormat: formatSelect.value});
  });
  jpgInput.addEventListener("change",()=> {
    chrome.storage.sync.set({jpgQuality: parseInt(jpgInput.value)});
  });
  savePathInput.addEventListener("change",()=> {
    chrome.storage.sync.set({savePath: savePathInput.value});
  });

  // Toplu kaydetme
  bulkBtn.addEventListener("click", async ()=>{
    const [tab] = await chrome.tabs.query({active:true,currentWindow:true});
    chrome.scripting.executeScript({
      target:{tabId: tab.id},
      func: () => Array.from(document.images).map(img=>img.src)
    }, async (results)=>{
      if(results && results[0].result){
        const urls = results[0].result;
        chrome.storage.sync.get(["defaultFormat","jpgQuality","savePath"], data=>{
          urls.forEach(url=>{
            chrome.runtime.sendMessage({action:"download",url,format:data.defaultFormat,options:data,saveAs:false});
          });
        });
      }
    });
  });

  // Geçmişi göster
  historyBtn.addEventListener("click",()=>{
    chrome.storage.local.get("history", data=>{
      const history = data.history || [];
      historyContainer.innerHTML = "";
      history.forEach(item=>{
        const div = document.createElement("div");
        div.textContent = `${item.filename} (${Math.round(item.size/1024)} KB)`;
        historyContainer.appendChild(div);
      });
      historyContainer.style.display = historyContainer.style.display==="none"?"block":"none";
    });
  });

  // Geçmişi temizle
  clearHistoryBtn.addEventListener("click",()=>{
    chrome.storage.local.set({history:[]});
    historyContainer.innerHTML="";
  });

  // İstatistikleri göster
  chrome.storage.local.get("stats", data=>{
    const stats = data.stats || {totalFiles:0,totalSize:0};
    statsElem.textContent = `Toplam resim: ${stats.totalFiles}, Toplam boyut: ${Math.round(stats.totalSize/1024)} KB`;
  });
});

document.getElementById("quickSaveBtn")?.addEventListener("click", async () => {
  const [tab] = await chrome.tabs.query({active:true,currentWindow:true});
  chrome.scripting.executeScript({
    target:{tabId: tab.id},
    func: () => {
      const img = document.querySelector("img:hover") || document.querySelector("img");
      return img ? img.src : null;
    }
  }, async (results)=>{
    const url = results?.[0]?.result;
    if(url){
      chrome.storage.sync.get(["defaultFormat","jpgQuality","savePath"], data=>{
        chrome.runtime.sendMessage({action:"download",url,format:data.defaultFormat,options:data,saveAs:false});
      });
    }
  });
});

