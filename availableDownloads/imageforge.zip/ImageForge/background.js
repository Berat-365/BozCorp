// Menüleri oluştur
chrome.runtime.onInstalled.addListener(() => {
  const menuItems = [
    {id: "quick_save", title: "Hızlı Kaydet"},
    {id: "save_choose", title: "Kaydet ve Seç…"},
    {id: "format_menu", title: "Format Seç"},
    {id: "edit_image", title: "Resmi Düzenle"}
  ];
  menuItems.forEach(m => chrome.contextMenus.create({id: m.id, title: m.title, contexts: ["image"]}));

  // Alt menü: format seçimi
  const formats = ["png", "jpg", "webp", "bmp", "avif"];
  formats.forEach(f => {
    chrome.contextMenus.create({
      id: "format_" + f,
      parentId: "format_menu",
      title: f.toUpperCase(),
      contexts: ["image"]
    });
  });
});

// Menü tıklama
chrome.contextMenus.onClicked.addListener(async (info, tab) => {
  if (!info.srcUrl) return;

  chrome.storage.sync.get(["defaultFormat","jpgQuality","savePath"], data => {
    // Hızlı kaydet
    if (info.menuItemId === "quick_save") {
      downloadImage(info.srcUrl, data.defaultFormat, data, false);
      return;
    }
    // Kaydet ve Seç
    if (info.menuItemId === "save_choose") {
      downloadImage(info.srcUrl, data.defaultFormat, data, true);
      return;
    }
    // Format menüsü
    if (info.menuItemId.startsWith("format_")) {
      const fmt = info.menuItemId.replace("format_","");
      downloadImage(info.srcUrl, fmt, data, true);
      return;
    }
    // Resim düzenleme
    if (info.menuItemId === "edit_image") {
      chrome.windows.create({
        url: chrome.runtime.getURL(`editor.html?image=${encodeURIComponent(info.srcUrl)}`),
        type: "popup",
        width: 500,
        height: 500
      });
    }
  });
});

// Hızlı kaydet / download fonksiyonu
async function downloadImage(url, format, options={}, saveAs=false) {
  try {
    const blob = await (await fetch(url)).blob();
    const bitmap = await createImageBitmap(blob);
    const canvas = new OffscreenCanvas(bitmap.width, bitmap.height);
    const ctx = canvas.getContext("2d");
    ctx.drawImage(bitmap,0,0);

    let mime = getMime(format);
    let blobOpts = {type: mime};
    if(format==="jpg" && options.jpgQuality) blobOpts.quality = options.jpgQuality/100;

    const converted = await canvas.convertToBlob(blobOpts);
    const dataUrl = await blobToDataURL(converted);

    const filename = (options.savePath ? options.savePath+"/" : "") + `saver_${Date.now()}.${format}`;
    chrome.downloads.download({url: dataUrl, filename, saveAs});

    // Geçmiş ve istatistik
    updateHistory(filename, converted.size);
  } catch(e){console.error("Saver Pro Hata:", e);}
}

// Mime tipi
function getMime(format){
  switch(format){
    case "png": return "image/png";
    case "jpg": return "image/jpeg";
    case "webp": return "image/webp";
    case "bmp": return "image/bmp";
    case "avif": return "image/avif";
    default: return "image/png";
  }
}

// Blob to DataURL
function blobToDataURL(blob){
  return new Promise(resolve=>{
    const reader = new FileReader();
    reader.onloadend=()=>resolve(reader.result);
    reader.readAsDataURL(blob);
  });
}

// Geçmiş ve istatistik
function updateHistory(filename, size){
  chrome.storage.local.get(["history","stats"], data=>{
    let history = data.history || [];
    let stats = data.stats || {totalFiles:0,totalSize:0};
    history.unshift({filename, date: Date.now(), size});
    stats.totalFiles += 1;
    stats.totalSize += size;
    // 100 entry limit
    if(history.length>100) history.pop();
    chrome.storage.local.set({history, stats});
  });
}

// Düzenlenmiş resmi kaydet (editor.js için)
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if(msg.action==="downloadEdited"){
    const dataUrl = msg.dataUrl;
    chrome.storage.sync.get(["savePath"], data=>{
      const filename = (data.savePath ? data.savePath+"/" : "") + `saver_edited_${Date.now()}.png`;
      chrome.downloads.download({url:dataUrl, filename, saveAs:true}, () => {
        // Geçmiş ve istatistik
        updateHistory(filename, dataUrl.length); // yaklaşık boyut
      });
    });
  }
});

// Kısayol ile hızlı kaydet
chrome.commands.onCommand.addListener(async (command) => {
  if (command === "quick-save") {
    const [tab] = await chrome.tabs.query({active:true,currentWindow:true});
    chrome.scripting.executeScript({
      target: {tabId: tab.id},
      func: () => {
        const img = document.querySelector("img:hover") || document.querySelector("img");
        return img ? img.src : null;
      }
    }, async (results) => {
      const url = results?.[0]?.result;
      if(url){
        chrome.storage.sync.get(["defaultFormat","jpgQuality","savePath"], data=>{
          downloadImage(url, data.defaultFormat, data, false);
        });
      } else {
        console.warn("Hızlı kaydetilecek resim bulunamadı!");
      }
    });
  }
});
