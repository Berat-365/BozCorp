document.addEventListener("DOMContentLoaded", async () => {
  const urlParams = new URLSearchParams(window.location.search);
  const imageUrl = urlParams.get("image");

  const canvas = document.getElementById("previewCanvas");
  const ctx = canvas.getContext("2d");
  const widthInput = document.getElementById("width");
  const heightInput = document.getElementById("height");
  const effectSelect = document.getElementById("effect");
  const formatSelect = document.getElementById("format");
  const rotateBtn = document.getElementById("rotate");
  const cropBtn = document.getElementById("crop");
  const applyBtn = document.getElementById("apply");

  let img = new Image();
  img.src = imageUrl;
  let currentAngle = 0;
  let cropRect = null;

  img.onload = () => {
    canvas.width = img.naturalWidth;
    canvas.height = img.naturalHeight;
    widthInput.value = canvas.width;
    heightInput.value = canvas.height;
    drawImage();
  };

  function drawImage() {
    ctx.save();
    ctx.clearRect(0,0,canvas.width,canvas.height);
    ctx.translate(canvas.width/2, canvas.height/2);
    ctx.rotate(currentAngle * Math.PI/180);
    ctx.filter = effectSelect.value !== "none" ? effectSelect.value === "grayscale" ? "grayscale(100%)" :
                 effectSelect.value === "sepia" ? "sepia(100%)" :
                 effectSelect.value === "invert" ? "invert(100%)" : "none" : "none";
    ctx.drawImage(img, -canvas.width/2, -canvas.height/2, canvas.width, canvas.height);
    ctx.restore();

    if(cropRect){
      ctx.strokeStyle = "#00a8ff";
      ctx.lineWidth = 2;
      ctx.strokeRect(cropRect.x, cropRect.y, cropRect.w, cropRect.h);
    }
  }

  // Input değişince boyut güncelle
  widthInput.addEventListener("input", () => { canvas.width = parseInt(widthInput.value); drawImage(); });
  heightInput.addEventListener("input", () => { canvas.height = parseInt(heightInput.value); drawImage(); });
  effectSelect.addEventListener("change", drawImage);

  // Döndürme
  rotateBtn.addEventListener("click", () => { currentAngle += 90; drawImage(); });


  // Kaydetme
  applyBtn.addEventListener("click", () => {
    let tempCanvas = document.createElement("canvas");
    let tempCtx = tempCanvas.getContext("2d");
    let saveW = canvas.width;
    let saveH = canvas.height;

    if(cropRect){
      tempCanvas.width = cropRect.w;
      tempCanvas.height = cropRect.h;
      tempCtx.drawImage(canvas, cropRect.x, cropRect.y, cropRect.w, cropRect.h, 0,0,cropRect.w,cropRect.h);
    } else {
      tempCanvas.width = saveW;
      tempCanvas.height = saveH;
      tempCtx.drawImage(canvas,0,0);
    }

    let mime = formatSelect.value === "jpg" ? "image/jpeg" : formatSelect.value === "png" ? "image/png" :
               formatSelect.value === "webp" ? "image/webp" :
               formatSelect.value === "bmp" ? "image/bmp" :
               "image/avif";

    let dataUrl = tempCanvas.toDataURL(mime);

    chrome.runtime.sendMessage({action:"downloadEdited", dataUrl, saveAs:true});
    window.close();
  });
});
